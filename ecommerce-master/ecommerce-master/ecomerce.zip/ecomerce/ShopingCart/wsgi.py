"""
WSGI config for shopingcart project.

It exposes the WSGI callable as a module-level variable named ``application``.

For more inimport os

from django.core.wsgi import get_wsgi_applicationformation on this file, see
https://docs.djangoproject.com/en/2.2/howto/deployment/wsgi/
"""



os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'shopingcarts.settings')

application = get_wsgi_application()
