import datetime
from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import OrderItemSerializer , OrderSerializers
from django.shortcuts import get_object_or_404
from ShopingCart.models import Order, OrderItem
from Profile.models import Profile
from Products.models import Products , Groups
from ShopingCart.extras import generate_order_id

def get_user_pending_order(request):
    user_profile = get_object_or_404(Profile , user = request.user)
    order = Order.objects.filter(owner = user_profile , is_ordered = False)
    if order:
        return order[0]
   
    return None
class Delete_order(APIView):
    def get(self , request , pk):
        item_to_delete = get_object_or_404(OrderItem , pk = pk)
        if item_to_delete:
            item_to_delete.delete()
        order = get_user_pending_order(request)
        if order is not None:
            items = OrderSerializers(order).data
            return Response(items)
        return None
    

class Add_to_cart(APIView):
    def get(self , request , pk):
        user_profile = get_object_or_404(Profile , user = request.user)
    
        product = Products.objects.filter(pk = pk).first()
        order = get_user_pending_order(request)
        item = OrderItem.objects.filter(product = product).first()
        if order and item in order.get_cart_item:
            return Response(None)
        order_item, status = OrderItem.objects.get_or_create(product = product)
        user_order , status = Order.objects.get_or_create(owner = user_profile , is_ordered = False )
        user_order.items.add(order_item)

        if status:
            user_order.ref_code = generate_order_id()
            user_order.save()
        data = OrderSerializers(user_order).data
        return Response(data)
class Order_detail(APIView):
    def get(self , request):
        order = get_user_pending_order(request)
        if order:
            items = OrderSerializers(order).data
            return Response(items)
        return None
class Update_transaction(APIView):
    ex_order = None
    ord_to_purc = None
    def get(self , request , pk): 
        existing_order = get_user_pending_order(request)
        order_to_purchase = get_object_or_404(Order ,pk = pk)
        self.ex_order = existing_order
        self.ord_to_purc = order_to_purchase
        dat = OrderSerializers(order_to_purchase , many = False).data
        return Response(dat)
    def post(self, request):
        street_adress = request.data.get('street_adress')
        appartment_adress = request.data.get('appartment_adress')
        zip_code = request.data.get('zip_code')
        note = request.data.get('note')

        self.ord_to_purc.is_ordered = True
        self.ord_to_purc.date_ordered = datetime.datetime.now()
        self.ord_to_purc.street_adress = street_adress
        self.ord_to_purc.appartment_adress = appartment_adress
        self.ord_to_purc.zip_code = zip_code
        self.ord_to_purc.note = note
        self.ord_to_purc.save()
        dat = OrderSerializers(self.ord_to_purc).data
        return Response(dat)
