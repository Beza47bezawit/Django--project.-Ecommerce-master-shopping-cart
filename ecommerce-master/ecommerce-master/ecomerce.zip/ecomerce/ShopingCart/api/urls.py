from django.contrib import admin
from django.urls import path
from .apiviews import  Order_detail , Add_to_cart,  Delete_order, Update_transaction
from django.contrib.auth.decorators import login_required



urlpatterns = [ 
    
    path('' , login_required(Order_detail.as_view()) , name ='order_summery'),

    path('<int:pk>/' , login_required(Add_to_cart.as_view()) , name = 'add_to_cart'),
    path('<int:pk>/delete' , login_required(Delete_order.as_view()) , name = 'add_to_cart'),
    path('<int:pk>/update' , login_required(Update_transaction.as_view()) , name = 'add_to_cart'),
   
    #path('success/' , views.)
    #path('item/delete/<int:id>/' , login_required(delete_from_cart) , name='delete_item'),
    #path('chekout/' , login_required(views.checkout) , name ='checkout'),
    #path('update-transaction/<int:id>/' , update_transaction_record , name = 'update_record')
]