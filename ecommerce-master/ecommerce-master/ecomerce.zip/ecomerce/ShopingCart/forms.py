from django import forms

from .models import Order


class FinalCheckOut(forms.ModelForm):
    class Meta:
        model = Order
        fields = [
            'street_address',
            'appartment_adress',
            'zip_code',
            'note'
        ]

 