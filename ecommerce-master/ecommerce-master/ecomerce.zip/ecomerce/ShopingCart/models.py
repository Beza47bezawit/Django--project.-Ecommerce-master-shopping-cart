from __future__ import unicode_literals
from django.db import models


from django.conf import settings
from django.contrib.auth import get_user_model
from django.db.models.signals import post_save
from Products.models import Products , Groups
from Profile.models import Profile


class OrderItem(models.Model):
    owner = models.ForeignKey(Profile , on_delete = models.SET_NULL, null = True)
    Group = models.ForeignKey(Groups , on_delete = models.CASCADE)
    image1 = models.ImageField(upload_to = 'products/{0}'.format(Group) , null = True , blank = True)
    name = models.CharField(max_length = 120)


    price = models.IntegerField()
    #owner  = models.OneToManyField(User )
    amount = models.IntegerField(default=1)
    is_ordered = models.BooleanField(default=False)
    date_aded = models.DateTimeField(auto_now=True)
    date_aded = models.DateTimeField(null = True)
    def __str__(self):
        return "{0} - {1}".format(self.name , self.amount)






class Order(models.Model):
    ref_code = models.CharField(max_length = 15)
    owner = models.ForeignKey(Profile , on_delete = models.SET_NULL, null = True)
    is_ordered = models.BooleanField(default=False)
    items = models.ManyToManyField(OrderItem, default = None)
    total = models.IntegerField(default=0)
    date_ordered = models.DateTimeField(auto_now=True)
    street_address = models.CharField(max_length = 50)
    appartment_adress = models.CharField(max_length = 50 , null = True , blank = True)
    zip_code = models.CharField(max_length = 25)
    note = models.TextField(blank=True , null=True)

    @property
    def get_cart_item(self):
        return self.items.all()
    def get_cart_number(self):
        return self.items.all().count()

    def get_cart_total(self):
        if self.items:
            return sum([item.price * item.amount for item in self.items.all()])
        return 0

    def __str__(self):

        return "{0} - {1}".format(self.owner.user.username , self.ref_code)
