from django.apps import AppConfig


class ShopingcartConfig(AppConfig):
    name = 'ShopingCart'
