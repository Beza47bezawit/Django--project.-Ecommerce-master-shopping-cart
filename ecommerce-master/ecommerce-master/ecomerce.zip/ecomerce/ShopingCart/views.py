from django.shortcuts import render, redirect , get_object_or_404
from django.core.mail import send_mail

from django.conf import settings

import datetime
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.urls import reverse
from Profile.models import Profile

from .forms import FinalCheckOut

from Products.models import Products , Groups

from ShopingCart.extras import generate_order_id
from ShopingCart.models import Order , OrderItem


def get_user_pending_order(request):
    user_profile = get_object_or_404(Profile , user = request.user)
    order = Order.objects.filter(owner = user_profile , is_ordered = False)
    if order:
        return order[0]
   
    return None


def add_to_cart(request , id):
    user_profile = get_object_or_404(Profile , user = request.user)
    product = Products.objects.filter(id = id).first()
    order = get_user_pending_order(request)
    
    if product in request.user.profile.ebook.all():
       
        return redirect(reverse('ShopingCart:order_summery'))
    if product:
        #geting or creating data based on the specific input
        order_item ,status = OrderItem.objects.get_or_create(owner = user_profile ,Group = product.Group , image1 = product.image1 , name = product.name , price = product.price )
        

    #untouche data
    user_order , status = Order.objects.get_or_create(owner = user_profile , is_ordered = False )
  
    

    user_order.items.add(order_item)

    if status:
        user_order.ref_code = generate_order_id()
        user_order.save()

    
    return redirect('../../')


def delete_from_cart(request , id):
    
    #
    profile = get_object_or_404(Profile ,user =  request.user)
    user_profile = get_object_or_404(Profile , user = request.user)
    item_to_delete = OrderItem.objects.filter( id = id)
    order = Order.objects.filter(owner = user_profile)
    
    order = get_user_pending_order(request)
    
    if item_to_delete:
       
       item_to_delete[0].delete() #deleting item
     
       if not order:
            return render(request , 'ShopingCart/cart.html' , {"err" : "No items has been selected yet :)"})
    
    return redirect(reverse('ShopingCart:order_summery'))
    
    

def order_details(request ):

    
    existing_orders = get_user_pending_order(request)
    
    if existing_orders:
        context = {
            'order' : existing_orders
        }

        return render(request , 'ShopingCart/cart.html' , context = context)
    return render(request , 'ShopingCart/cart.html' , {"err" : "No items has been selected yet :)"})

def checkout(request):




    existing_order = get_user_pending_order(request)
    form = FinalCheckOut(request.POST or None)
    if existing_order:
        context = {
            'form' : form,
            'order' : existing_order,
        }
        return render(request , 'ShopingCart/chekout.html' , context = context)
    return render(request , 'ShopingCart/cart.html' , {"err" : "No Items To Checkout"})


def update_transaction_record(request , id):

    
   
    existing_order = get_user_pending_order(request)
    order_to_purchase = get_object_or_404(Order , id = id)
    form = FinalCheckOut(request.POST or None)
    if form.is_valid():

        street_address = form.cleaned_data.get('street_address')
        appartment_adress = form.cleaned_data.get('appartment_adress')

        zip_code = form.cleaned_data.get('zip_code')
        note = form.cleaned_data.get('note')
        order_to_purchase.is_ordered = True
        order_to_purchase.date_ordered = datetime.datetime.now()
        order_to_purchase.street_address = street_address
        order_to_purchase.appartment_adress = appartment_adress
        order_to_purchase.zip_code = zip_code
        order_to_purchase.note = note
        order_to_purchase.total = order_to_purchase.get_cart_total()
        dumy = order_to_purchase
        order_to_purchase.save()
        order_items = order_to_purchase.items.all()
        order_items.update(is_ordered = True , date_aded = datetime.datetime.now())

        

        #user_profile = get_object_or_404(Profile , user=request.user)

        order_products = [item for item in order_items]

        #user_profile.ebook.add(*order_products)
        #user_profile.save()

        
        message = 'THings that has been ordered'
        email_from = settings.EMAIL_HOST_USER
        email_to = request.user.email
        recipient_list = [ email_to,]
        send_mail( message, message, email_from, recipient_list )

 
        return redirect('../../../')
    context = {
        'form' : form,
        'order' : existing_order
    }
    return render(request , 'ShopingCart/chekout.html' , context = context)



    


    







































