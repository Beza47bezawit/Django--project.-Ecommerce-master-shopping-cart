from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.auth.decorators import login_required

app_name = 'ShopingCart'

urlpatterns = [
    path('<int:id>/' , login_required(views.add_to_cart) , name = 'add_to_cart'),
    path('order-summery/' , login_required(views.order_details) , name ='order_summery'),
    #path('success/' , views.)
    path('item/delete/<int:id>/' , login_required(views.delete_from_cart) , name='delete_item'),
    #path('chekout/' , login_required(views.checkout) , name ='checkout'),
    path('update-transaction/<int:id>/' , views.update_transaction_record , name = 'update_record')
]