from django.contrib import admin
from django.urls import path
from .apiviews import GroupList , Product_list ,Product_detail


urlpatterns = [
    path('' , GroupList.as_view() , name = 'GroupList' ),
    path('<int:pk>/' , Product_list.as_view() , name = 'ProductList' ),
     path('detail/<int:pk>/' , Product_detail.as_view() , name = 'ProductList' ),
]