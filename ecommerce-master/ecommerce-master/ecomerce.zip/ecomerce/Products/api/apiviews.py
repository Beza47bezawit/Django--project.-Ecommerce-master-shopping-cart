from rest_framework import generics
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import ProductSerializer , GroupSerializer
from django.shortcuts import get_object_or_404
from Products.models import Products , Groups


class GroupList(generics.ListAPIView):
    queryset = Groups.objects.all()
    serializer_class = GroupSerializer

class Product_list(APIView):
    def get(self , request , pk):
        Group = get_object_or_404(Groups , pk = pk)
        Products = Group.products_set.all()

        data = ProductSerializer(Products , many = True).data

        return Response(data)

class Product_detail(APIView):
    def get(self , request , pk):
        Product = get_object_or_404(Products , pk = pk)

        data = ProductSerializer(Product ).data
        return Response(data)
