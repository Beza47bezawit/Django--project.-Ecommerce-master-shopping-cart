from django.contrib import admin
from django.urls import path
from . import views

app_name = 'Groups'
urlpatterns = [
    path('' , views.Home.as_view() , name = 'Home' ),
    path('<int:id>/' , views.Product_list.as_view() , name = 'detail'),
    path('<int:id>/detail/' , views.detail , name = 'Detail_view'),
    path('search/' , views.Search.as_view() , name = 'search' ),
]