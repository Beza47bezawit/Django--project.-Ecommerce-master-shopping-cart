#from __future__ import unicode_literals
from django.db import models


class Groups(models.Model):
    Name = models.CharField(max_length = 200)
    ThumbNail = models.ImageField(upload_to = 'thumbnail/image' , null = True , blank =True)
    


    def __str__(self):
        return self.Name


# Create your models here.
class Products(models.Model):
    Group = models.ForeignKey(Groups , on_delete = models.CASCADE)
    image1 = models.ImageField(upload_to = 'products/a' , null = True , blank = True)
    image2 = models.ImageField(upload_to = 'products/a' , null = True , blank = True)
    image3 = models.ImageField(upload_to = 'products/a' , null = True , blank = True)
    image4 = models.ImageField(upload_to = 'products/a' , null = True , blank = True)
    #colour = models.CharField(max_length = 30 )
    description = models.TextField(default="hello world")
    name = models.CharField(max_length = 120)
    
    price = models.IntegerField()
    def __str__(self):
        return self.name