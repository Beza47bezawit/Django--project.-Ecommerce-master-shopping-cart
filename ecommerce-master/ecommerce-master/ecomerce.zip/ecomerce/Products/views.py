from django.shortcuts import render , get_object_or_404
from django.views import View
from .models import Products , Groups
from ShopingCart.models import Order

from django.core.paginator import EmptyPage, PageNotAnInteger, Paginator
# Create your views here.

from ShopingCart.views import get_user_pending_order
class Home(View):
    template_name = 'Products/home.html'

    def get(self , request , *args , **kwargs):

        objs = Groups.objects.all()
        order = ""
        if request.user.is_authenticated:
            order = get_user_pending_order(request)
        
        context = {
            'objects' : objs,
            'order' : order
             }

        return render(request , self.template_name , context)
class Search(View):
    template_name = 'Products/home.html'
    groups = Groups.objects.all()
    def post(self , request , *args , **kwargs):
        name = request.POST['search']
      
        data = []
        
        for group in self.groups:
            if name in group.Name:
                data.append(group)
            else:
                continue

        if request.user.is_authenticated:
            order = get_user_pending_order(request)
       
        context = {
            'objects' : data,
            'order' : order
        }
        return render(request , self.template_name , context)
       # return render(request , self.template_name , context)
class Product_list(View):
    template_name = 'Products/product_list.html'

    def get(self , request , id = None, *args , **kwargs):
        groups = Groups.objects.all()
        Group = get_object_or_404(Groups , id = id)
        order = ""
        if request.user.is_authenticated:
            order = get_user_pending_order(request)
        object_list = Group.products_set.all()
        paginator = Paginator(object_list, 2) # Show 25 contacts per page

        page = request.GET.get('page')
        try:
            object_list = paginator.get_page(page)
        except PageNotAnInteger:
           object_list= paginator.get_page(1)
        except EmptyPage:
            object_list = paginator.get_page(paginator.num_pages)
        context = {
            'order' : order,
            'Group' : Group,
            'groups' : groups,
            'object_list' : object_list,
            'id' : id
            #'current_order_products' : current_ordered_products

        }
        return render(request , self.template_name , context)
'''       
class Try(View):

    def get(self , request , id = None, *args , **kwargs):
        filtered_orders = Order.objects.filter(owner = request.user.profile , is_ordered = False)
        current_ordered_products = []
        if filtered_orders.exists():
            user_order = filtered_orders[0]
            user_order_items = user_order.items.all()
            current_ordered_products = [product.product for product in user_order_items]'''


def detail(request , id):
    order = ""
    obj = get_object_or_404(Products , id = id)
    
    
    if request.user.is_authenticated:
        order = get_user_pending_order(request)
     


    
    context = {
       
        'order' : order,
        'object' : obj,
        'id' : id
    }

    return render(request , 'Products/product_detail.html' , context)

