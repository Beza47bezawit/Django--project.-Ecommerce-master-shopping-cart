from django.shortcuts import render , get_object_or_404

# Create your views here.

from .models import Profile
from ShopingCart.models import Order

from django.views import View


class My_profile(View):
    template_name = 'Profile/profile.html'
    model = Profile
    def get(self , request , *args , **kwargs):
        my_user_profile = get_object_or_404(self.model , user = request.user)
        my_orders = Order.objects.filter(is_ordered=True , owner = my_user_profile)
        context = {
            'my_orders' : my_orders
        }
        return render(request , self.template_name , context)

