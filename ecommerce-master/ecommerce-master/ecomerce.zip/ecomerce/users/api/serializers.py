from rest_framework import serializers
from django.contrib.auth import (authenticate ,get_user_model ,login , logout)


User = get_user_model()

class UserSerializers(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'
