from django.contrib import admin
from django.urls import path
from . import views

from django.contrib.auth.views import LoginView , LogoutView , logout_then_login
app_name = 'Users'



urlpatterns = [
    path('' , views.registration_view , name = "register"),
    path('signout/' , LogoutView.as_view() , name = "logout"),
    path('signin/' , LoginView.as_view( template_name='users/login.html', ) , name = 'Login'),
]