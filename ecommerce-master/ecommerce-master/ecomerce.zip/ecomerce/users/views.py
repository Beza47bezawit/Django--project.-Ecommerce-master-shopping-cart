from django.shortcuts import render, redirect

# Create your views here.
from .forms import UserRegistration



def registration_view(request):
    if not request.user.is_authenticated:
        title = "Registration"
        form = UserRegistration(request.POST or None)
        if form.is_valid():
        
            user = form.save(commit=False)
            password = form.cleaned_data.get('password')
            user.set_password(password)
            user.save()
            #login(request , user)
            return redirect('../')
        context = {
            'title' : title,
            'form' : form
        }
        return render(request , 'users/register.html' , context)
    return render(request , 'users/register.html' , context = {'err' : 'Forbidon attempt! sign out first'})